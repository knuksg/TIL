from django.db import models
from imagekit.models import ProcessedImageField, ImageSpecField
from imagekit.processors import ResizeToFill


# Create your models here.
class Movie(models.Model):
    title = models.CharField(max_length=30)
    content = models.TextField()
    image = models.ImageField(upload_to='images/', blank=True)
    image_thumbnail = ImageSpecField(source='image',
                                processors=[ResizeToFill(70, 100)],
                                format='JPEG',
                                options={'quality': 60})

    def __str__(self):
        return self.title
